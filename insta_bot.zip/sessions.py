import json, os, tempfile, time
import get_cockise

_SESSION_FILE = ".sessions.json"
_SESSION_EXPIRY = 30 * 24 * 60 * 60
def _atomic_write_json(path, obj):
    dirpath = os.path.dirname(os.path.abspath(path)) or "."
    fd, tmp_path = tempfile.mkstemp(dir=dirpath, prefix=".tmp_sessions_")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as tmpf:
            json.dump(obj, tmpf, ensure_ascii=False, indent=4)
            tmpf.flush()
            os.fsync(tmpf.fileno())
        os.replace(tmp_path, path)
    finally:
        if os.path.exists(tmp_path):
            try: os.remove(tmp_path)
            except: pass

def _load_sessions():
    if not os.path.exists(_SESSION_FILE):
        return []
    try:
        with open(_SESSION_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, list) else []
    except:
        return []

def _save_session(session):
    sessions = _load_sessions()
    uname = session["username"]
    for i, s in enumerate(sessions):
        if s.get("username") == uname:
            sessions[i] = session
            _atomic_write_json(_SESSION_FILE, sessions)
            return
    sessions.append(session)
    _atomic_write_json(_SESSION_FILE, sessions)

def _cleanup_expired_sessions():
    sessions = _load_sessions()
    now = int(time.time())
    new_sessions = [s for s in sessions if now - s.get("created_at", 0) < _SESSION_EXPIRY]
    if len(new_sessions) != len(sessions):
        _atomic_write_json(_SESSION_FILE, new_sessions)

def get_session_data(username, password=None):
    _cleanup_expired_sessions()
    sessions = _load_sessions()
    now = int(time.time())
    for s in sessions:
        if s.get("username") == username and now - s.get("created_at", 0) < _SESSION_EXPIRY:
            return s
    if not password:
        raise ValueError("Session not found and password not provided")

    test, token, ds_user, www_claim, mid = get_cockise.get_cook(username, password)
    if test==False:
        raise ValueError(f"Login failed: {ds_user}")
    session_data = {
        "username": username,
        "token": token,
        "ds_user": ds_user,
        "www_claim": www_claim,
        "mid": mid,
        "created_at": now}
    _save_session(session_data)
    return session_data

def list_users():
    _cleanup_expired_sessions()
    sessions = _load_sessions()
    sessions_sorted = sorted(sessions, key=lambda x: x.get("created_at", 0))
    return [s.get("username") for s in sessions_sorted]

def delete_session(username):
    sessions = _load_sessions()
    new_sessions = [s for s in sessions if s.get("username") != username]
    if len(new_sessions) != len(sessions):
        _atomic_write_json(_SESSION_FILE, new_sessions)
        return True
    return False
