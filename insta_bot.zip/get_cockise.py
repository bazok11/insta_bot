
#استخراج توكن وكوكيز

import requests, uuid, random, time, agint_insta,device_fp

def get_cook(user, pas):
    
    guid,phone_id,user_agent,x_pigeon_session_id,x_ig_device_id,x_ig_family_device_id=device_fp.hd()
    
    url = "https://i.instagram.com/api/v1/accounts/login/"
    payload = {
        'signed_body': (
            "SIGNATURE."
            '{"jazoest":"22299",'
            '"country_codes":"[{\\"country_code\\":\\"20\\",\\"source\\":[\\"default\\"]}]",'
            f'"phone_id":"{str(phone_id)}",'
            f'"enc_password":"#PWD_INSTAGRAM:0:{int(time.time())}:{pas}",'
            f'"username":"{user}",'
            '"adid":"00000000-0000-0000-0000-000000000000",'
            f'"guid":"{str(guid)}",'
            '"device_id":"android-cfc948366e9e83d2",'
            '"google_tokens":"[]",'
            '"login_attempt_count":"1"}')}
    headers = {
        'User-Agent': str(user_agent),
        'x-ig-app-locale': "ar_EG_#u-nu-latn",
        'x-ig-device-locale': "ar_EG_#u-nu-latn",
        'x-ig-mapped-locale': "ar_AR",
        'x-pigeon-session-id': str(x_pigeon_session_id),
        'x-pigeon-rawclienttime': f"{time.time():.3f}",
        'x-ig-bandwidth-speed-kbps': str(round(random.uniform(100, 1500), 3)),
        'x-ig-bandwidth-totalbytes-b': "0",
        'x-ig-bandwidth-totaltime-ms': "0",
        'x-ig-app-startup-country': "IQ",
        'x-bloks-version-id': "8dab28e76d3286a104a7f1c9e0c632386603a488cf584c9b49161c2f5182fe07",
        'x-ig-www-claim': "0",
        'x-bloks-is-layout-rtl': "true",
        'x-ig-device-id': str(x_ig_device_id),
        'x-ig-family-device-id': str(x_ig_family_device_id),
        'x-ig-android-id': "android-cfc948366e9e83d2",
        'x-ig-timezone-offset': "10800",
        'x-ig-nav-chain': "AD1:login_landing:1:warm_start::",
        'x-fb-connection-type': "WIFI",
        'x-ig-connection-type': "WIFI",
        'x-ig-capabilities': "3brTv10=",
        'x-ig-app-id': "567067343352427",
        'priority': "u=3",
        'accept-language': "ar-EG, en-US",
        'ig-intended-user-id': "0",
        'x-fb-http-engine': "Liger"}

    response = requests.post(url, data=payload, headers=headers, timeout=20)
    hed = response.headers
    try:
        test=True
        token = hed.get("ig-set-authorization")
        ds_user = hed.get("ig-set-ig-u-ds-user-id")
        www_claim = hed.get("x-ig-set-www-claim")
        try:
            mid = str(hed.get("Set-Cookie")).split("mid=")[1].split(";")[0]
        except:
            mid = hed.get("ig-set-x-mid")
        
        
    except Exception as x:
        test=False
        token = False
        ds_user = x
        www_claim = False
        mid = False
    return test, token, ds_user, www_claim, mid
