from time import sleep
from sessions import get_session_data
from  get_id_ax import get_id_ax
from file_data import file_line
from post_like import like
from post_comment import comment
from get_word import word
import random
from post_status import test
from updates import update

ok,testrs=update()
if ok==True:
    print("Your tool has been updated ✅  \n")
else:
    print(testrs);print()
    
username="ewsef2025"
pasoowrd="32Kscs2Ezz0##"

coc=get_session_data(username,pasoowrd)
token=coc["token"]
ds_user=coc["ds_user"]
www_claim=coc["www_claim"]
mid=coc["mid"]

def get_id():
    idd,np=file_line("ids_exp.txt")
    if np < 5:
        ids=get_id_ax(token, ds_user, www_claim, mid)
        print(ids)
    return idd

for _ in range(20):
    iiii=get_id()
    testt,reasons=test(token, ds_user, www_claim, mid,iiii)
    
    if testt ==True:
        
        likes=like(token, ds_user, www_claim, mid,iiii)
        print(likes)
        sleep(random.uniform(2.6, 4.4))
        
        com=comment(token, ds_user, www_claim, mid,iiii,word("words.txt"))
        print(com)
        print()
        sleep(random.uniform(5.6, 7.4))
        
    elif testt ==False:
        print(f"{reasons}: {iiii}")
        print()
        
    else:
        print(testt,reasons)
        exit()