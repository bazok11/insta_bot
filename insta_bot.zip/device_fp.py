import os,json,uuid,agint_insta

def hd():
    FP_PATH = ".hed.json"
    def gen_fingerprint():
        return {
            "x_ig_family_device_id": str(uuid.uuid4()),
            "x_ig_device_id": str(uuid.uuid4()),
            "x_pigeon_session_id": str(uuid.uuid4()),
            "user_agent": str(agint_insta.random_agint()),
            "phone_id": str(uuid.uuid4()),
            "guid": str(uuid.uuid4()),
            "x_ig_android_id": "android-cfc948366e9e83d2",}
    
    def save_fp(fp, path=FP_PATH):
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(fp, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
        try:
            os.chmod(path, 0o600)
        except:
            pass
        return path
    
    def load_fp(path=FP_PATH):
        if not os.path.exists(path):
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None
    
    def ensure_fingerprint(path=FP_PATH):
        fp = load_fp(path)
        if fp:
            return fp
        fp = gen_fingerprint()
        save_fp(fp, path)
        return fp
    
    
    fp = ensure_fingerprint()
    guid=fp["guid"]
    phone_id=fp["phone_id"]
    user_agent=fp["user_agent"]
    x_pigeon_session_id=fp["x_pigeon_session_id"]
    x_ig_device_id=fp["x_ig_device_id"]
    x_ig_family_device_id=fp["x_ig_family_device_id"]
    return guid,phone_id,user_agent,x_pigeon_session_id,x_ig_device_id,x_ig_family_device_id