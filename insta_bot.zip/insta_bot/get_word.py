import os, random

def word(file_path, last_path='.last_word'):
    if not os.path.exists(file_path):
        return None
    with open(file_path, 'r', encoding='utf-8') as f:
        lines = [line.strip() for line in f if line.strip()]
    if not lines:
        return None

    last = None
    if os.path.exists(last_path):
        try:
            with open(last_path, 'r', encoding='utf-8') as f:
                last = f.read().strip()
        except:
            last = None
    if len(lines) == 1:
        word = lines[0]
    else:
        for _ in range(5):
            word = random.choice(lines)
            if word != last:
                break
        else:
            if last in lines:
                idx = lines.index(last)
                word = lines[(idx + 1) % len(lines)]
            else:
                choices = [w for w in lines if w != last]
                word = random.choice(choices) if choices else random.choice(lines)
    try:
        with open(last_path, 'w', encoding='utf-8') as f:
            f.write(word)
    except:
        pass
    return word
