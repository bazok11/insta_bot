import requests,json,device_fp,uuid,time,random


def comment(token, ds_user, www_claim, mid,iiii,txt):
    
    guid,phone_id,user_agent,x_pigeon_session_id,x_ig_device_id,x_ig_family_device_id=device_fp.hd()
    
    url = f"https://i.instagram.com/api/v1/media/{iiii}/comment/"
    data= {
    "user_breadcrumb": "3TUmxWWfsI9KhnK5l5+oTUUaaOhB1VEMuDVW66hs/Yk=NCAxNTcxIDAgMTc2MjE3NDc2OTYxMQ==",
    "inventory_source": "recommended_explore_chaining_model",
    "delivery_class": "organic",
    "idempotence_token": str(uuid.uuid4()),
    "carousel_index": "0",
    "radio_type": "wifi-none",
    "_uid": str(ds_user),
    "_uuid": str(x_ig_device_id),
    "nav_chain": "ExploreFragment:explore_popular:10:main_search::,DiscoveryChainingFeedFragment:feed_contextual_chain:12:button::,CommentThreadFragment:comments_v2:15:button::",
    "logging_info_token": "269a9e938b1147cfaf89f8ab31af05cd",
    "comment_text": str(txt),
    "is_carousel_bumped_post": "false",
    "container_module": "comments_v2_feed_contextual_chain",
    "feed_position": "2"}
    
    payload = {"signed_body": f"SIGNATURE.{json.dumps(data, separators=(',', ':'))}"}



    headers = {
  'User-Agent': str(user_agent),
  'x-ig-app-locale': "ar_EG_#u-nu-latn",
  'x-ig-device-locale': "ar_EG_#u-nu-latn",
  'x-ig-mapped-locale': "ar_AR",
  'x-pigeon-session-id': str(x_pigeon_session_id),
  'x-pigeon-rawclienttime': f"{time.time():.3f}",
  'x-ig-bandwidth-speed-kbps': f"{random.uniform(300.0, 1500.0):.3f}",
  'x-ig-bandwidth-totalbytes-b': str(random.randint(1000000, 10000000)),
  'x-ig-bandwidth-totaltime-ms': str(random.randint(1000, 20000)),
  'x-ig-app-startup-country': "IQ",
  'x-bloks-version-id': "8dab28e76d3286a104a7f1c9e0c632386603a488cf584c9b49161c2f5182fe07",
  'x-ig-www-claim': str(www_claim),
  'x-bloks-is-layout-rtl': "true",
  'x-ig-device-id': str(x_ig_device_id),
  'x-ig-family-device-id': str(x_ig_family_device_id),
  'x-ig-android-id': "android-cfc948366e9e83d2",
  'x-ig-timezone-offset': "10800",
  'x-ig-nav-chain': "ExploreFragment:explore_popular:10:main_search::,DiscoveryChainingFeedFragment:feed_contextual_chain:12:button::,CommentThreadFragment:comments_v2:15:button::",
  'x-ig-salt-ids': "587075607",
  'x-fb-connection-type': "WIFI",
  'x-ig-connection-type': "WIFI",
  'x-ig-capabilities': "3brTv10=",
  'x-ig-app-id': "567067343352427",
  'priority': "u=3",
  'accept-language': "ar-EG, en-US",
  'authorization': str(token),
  'x-mid': str(mid),
  'ig-u-ds-user-id': str(ds_user),
  'ig-u-rur': f"CLN,{ds_user},1793710770:01feea8b109fe669b7f05f4d2c0bf32bbfab7190ea0e59d94edf5a69d7608aa1378cccbe",
  'ig-intended-user-id': str(ds_user),
  'x-fb-http-engine': "Liger",
  'x-fb-client-ip': "True",
  'x-fb-server-cluster': "True"}
  
    try:
        response = requests.post(url, data=payload, headers=headers)
        resp_json = {}
        try:
            resp_json = response.json()
        except:
            pass
        if resp_json.get("status") == "ok" and resp_json.get("comment", {}).get("status") == "Active" and resp_json.get("comment", {}).get("pk"):
            return "comment", True, str(txt)
        elif "comments_disabled" in response.text:
            return "comment", False, None
        else:
            return "comment", False, response.text
    except Exception as e:
        return "comment", False, str(e)
    