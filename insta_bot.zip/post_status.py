import requests,uuid,time,random,device_fp,re,json



def test(token, ds_user, www_claim, mid,line):
    
    guid,phone_id,user_agent,x_pigeon_session_id,x_ig_device_id,x_ig_family_device_id=device_fp.hd()
    
    url = f"https://i.instagram.com/api/v1/media/{line}/info/"
    headers = {
  'User-Agent': str(user_agent),
  'x-ig-app-locale': "ar_EG_#u-nu-latn",
  'x-ig-device-locale': "ar_EG_#u-nu-latn",
  'x-ig-mapped-locale': "ar_AR",
  'x-pigeon-session-id': str(x_pigeon_session_id),
  'x-pigeon-rawclienttime': f"{time.time():.3f}",
  'x-ig-bandwidth-speed-kbps': f"{random.uniform(300.0, 1500.0):.3f}",
  'x-ig-bandwidth-totalbytes-b': str(random.randint(1000000, 10000000)),
  'x-ig-bandwidth-totaltime-ms': str(random.randint(1000, 20000)),
  'x-ig-app-startup-country': "IQ",
  'x-bloks-version-id': "8dab28e76d3286a104a7f1c9e0c632386603a488cf584c9b49161c2f5182fe07",
  'x-ig-www-claim': str(www_claim),
  'x-bloks-is-layout-rtl': "true",
  'x-ig-device-id': str(x_ig_device_id),
  'x-ig-family-device-id': str(x_ig_family_device_id),
  'x-ig-android-id': "android-cfc948366e9e83d2",
  'x-ig-timezone-offset': "10800",
  'x-ig-nav-chain': "ExploreFragment:explore_popular:10:main_search::,DiscoveryChainingFeedFragment:feed_contextual_chain:12:button::,CommentThreadFragment:comments_v2:15:button::",
  'x-ig-salt-ids': "587075607",
  'x-fb-connection-type': "WIFI",
  'x-ig-connection-type': "WIFI",
  'x-ig-capabilities': "3brTv10=",
  'x-ig-app-id': "567067343352427",
  'priority': "u=3",
  'accept-language': "ar-EG, en-US",
  'authorization': str(token),
  'x-mid': str(mid),
  'ig-u-ds-user-id': str(ds_user),
  'ig-u-rur': f"CLN,{ds_user},1793710770:01feea8b109fe669b7f05f4d2c0bf32bbfab7190ea0e59d94edf5a69d7608aa1378cccbe",
  'ig-intended-user-id': str(ds_user),
  'x-fb-http-engine': "Liger",
  'x-fb-client-ip': "True",
  'x-fb-server-cluster': "True"}

    
    response = requests.get(url, headers=headers)
    data = json.loads(response.text)
    if data.get("status") == "fail" and data.get("message") == "Media not found or unavailable":
        return False, "Deleted post 🗑️"
    cit = data.get("items", [{}])[0].get("comment_inform_treatment")
    if cit is None or (isinstance(cit, dict) and cit.get("action_type") is None):
        return True, True
    if cit is True:
        return False, "Comments are not allowed. 🚫"
    return "Error unknown", data
    