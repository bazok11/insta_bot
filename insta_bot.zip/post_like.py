import requests,uuid,time,random,device_fp


uu3=str(uuid.uuid4())
    
def like(token, ds_user, www_claim, mid,line=None):
    
    guid,phone_id,user_agent,x_pigeon_session_id,x_ig_device_id,x_ig_family_device_id=device_fp.hd()
    
    if line==None:
        return "Error | An empty ID file cannot be used ⭕"
        
    headers = {
    'User-Agent': str(user_agent),
    'Content-Type': 'application/x-www-form-urlencoded; application/x-www-form-urlencoded; charset=UTF-8',
    'x-ig-app-locale': 'ar_EG_#u-nu-latn',
    'x-ig-device-locale': 'ar_EG_#u-nu-latn',
    'x-ig-mapped-locale': 'ar_AR',
    'x-pigeon-session-id': str(x_pigeon_session_id),
    'x-pigeon-rawclienttime': f"{time.time():.3f}",
    'x-ig-bandwidth-speed-kbps': f"{random.uniform(300.0, 1500.0):.3f}",
    'x-ig-bandwidth-totalbytes-b': str(random.randint(1000000, 10000000)),
    'x-ig-bandwidth-totaltime-ms': str(random.randint(1000, 20000)),
    'x-ig-app-startup-country': 'IQ',
    'x-bloks-version-id': '8dab28e76d3286a104a7f1c9e0c632386603a488cf584c9b49161c2f5182fe07',
    'x-ig-www-claim': str(www_claim),
    'x-bloks-is-layout-rtl': 'true',
    'x-ig-device-id': str(x_ig_device_id),
    'x-ig-family-device-id': str(x_ig_family_device_id),
    'x-ig-android-id': 'android-cfc948366e9e83d2',
    'x-ig-timezone-offset': '10800',
    'x-ig-nav-chain': 'ExploreFragment:explore_popular:4:main_search::,DiscoveryChainingFeedFragment:feed_contextual_chain:5:button::',
    'x-fb-connection-type': 'WIFI',
    'x-ig-connection-type': 'WIFI',
    'x-ig-capabilities': '3brTv10=',
    'x-ig-app-id': '567067343352427',
    'priority': 'u=3',
    'accept-language': 'ar-EG, en-US',
    'authorization': str(token),
    'x-mid': str(mid),
    'ig-u-ds-user-id': str(ds_user),
    'ig-u-rur': f'CLN,{ds_user},1793461187:01fe6c74bf67e6f5471d587a738dc99f8fece9627741b1ac35d2b3f080905ed0adc02d57',
    'ig-intended-user-id': str(ds_user),
    'x-fb-http-engine': 'Liger',
    'x-fb-client-ip': 'True',
    'x-fb-server-cluster': 'True'}

    data = {
    'signed_body': 'SIGNATURE.{"inventory_source":"recommended_explore_grid_cover_model","delivery_class":"organic","tap_source":"button","media_id":"'+str(line)+',"chaining_session_id":"'+str(uu3)+'","radio_type":"wifi-none","_uid":"'+str(ds_user)+'","_uuid":"'+str(x_ig_device_id)+',"nav_chain":"ExploreFragment:explore_popular:4:main_search::,DiscoveryChainingFeedFragment:feed_contextual_chain:5:button::","logging_info_token":"ed29a4de13204783a1745281829b8687","parent_m_pk":"'+str(line)+'","is_carousel_bumped_post":"false","container_module":"feed_contextual_chain","feed_position":"0"}',
    'd': '0'}

    response = requests.post(f'https://i.instagram.com/api/v1/media/{line}/like/', headers=headers, data=data)
    if response.json()["status"]== "ok":
        return "like",True ,line
    else:
        return "like",False,line
