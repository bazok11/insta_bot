import os

def file_line(file_path):
    if not os.path.exists(file_path):
        return None, 0
    with open(file_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    if not lines:
        return None, 0
    first_line = lines[0].rstrip('\n')
    remaining = lines[1:]
    with open(file_path, 'w', encoding='utf-8') as f:
        f.writelines(remaining)
    return first_line, len(remaining)
