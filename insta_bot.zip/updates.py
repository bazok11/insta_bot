import requests
import os
import zipfile
import shutil

def update():
    url_zip = "https://raw.githubusercontent.com/bazok11/insta_bot/main/insta_bot.zip"
    sha_api = "https://api.github.com/repos/bazok11/insta_bot/git/blobs/b37f12532787b667f9aea8b8f1f1b212ccb50b76"
    local_file = "insta_bot.zip"
    sha_file = "insta_bot.sha"

    # الحصول على SHA من GitHub
    resp = requests.get(sha_api)
    if resp.status_code != 200:
        return False
    remote_sha = resp.json().get("sha")
    if not remote_sha:
        return False

    # قراءة SHA المحلي
    local_sha = None
    if os.path.exists(sha_file):
        with open(sha_file, "r") as f:
            local_sha = f.read().strip()

    # تحميل الملف إذا تغير SHA أو لم يوجد محليًا
    if local_sha != remote_sha or not os.path.exists(local_file):
        r = requests.get(url_zip, stream=True)
        if r.status_code == 200:
            with open(local_file, "wb") as f:
                for chunk in r.iter_content(1024):
                    f.write(chunk)
            with open(sha_file, "w") as f:
                f.write(remote_sha)

            # فك الضغط واستبدال الملفات في مسار التشغيل
            with zipfile.ZipFile(local_file, 'r') as zip_ref:
                for member in zip_ref.infolist():
                    # استخراج الملف في مسار التشغيل مباشرة
                    extracted_path = os.path.join(os.getcwd(), os.path.basename(member.filename))
                    with zip_ref.open(member) as source, open(extracted_path, 'wb') as target:
                        shutil.copyfileobj(source, target)

            # حذف الملف المضغوط بعد النجاح
            os.remove(local_file)
            return True

    return False
