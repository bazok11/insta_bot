import requests
import os
import zipfile

def update():
    url_zip = "https://raw.githubusercontent.com/bazok11/insta_bot/main/insta_bot.zip"
    api_url = "https://api.github.com/repos/bazok11/insta_bot/contents/insta_bot.zip"
    local_file = "insta_bot.zip"
    sha_dir = "/storage/emulated/0/insta_bot_sha"
    sha_file = os.path.join(sha_dir, "insta_bot.sha")

    os.makedirs(sha_dir, exist_ok=True)

    # الحصول على SHA الحالي من GitHub
    resp = requests.get(api_url)
    if resp.status_code != 200:
        return False
    remote_sha = resp.json().get("sha")
    if not remote_sha:
        return False

    # قراءة SHA المحلي
    local_sha = None
    if os.path.exists(sha_file):
        with open(sha_file, "r") as f:
            local_sha = f.read().strip()

    # التحديث فقط إذا اختلف SHA أو الملف غير موجود
    if local_sha != remote_sha or not os.path.exists(local_file):
        r = requests.get(url_zip, stream=True)
        if r.status_code == 200:
            with open(local_file, "wb") as f:
                for chunk in r.iter_content(1024):
                    f.write(chunk)

            # فك الضغط فوق الملفات القديمة
            with zipfile.ZipFile(local_file, 'r') as zip_ref:
                for member in zip_ref.namelist():
                    zip_ref.extract(member, os.getcwd())

            # تحديث SHA المحلي
            with open(sha_file, "w") as f:
                f.write(remote_sha)

            # حذف الملف المضغوط بعد الاستخراج
            os.remove(local_file)

            return True

    return False
