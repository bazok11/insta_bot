import requests
import os
import zipfile

def update():
    url_zip = "https://raw.githubusercontent.com/bazok11/insta_bot/main/insta_bot.zip"
    sha_api = "https://api.github.com/repos/bazok11/insta_bot/git/blobs/b37f12532787b667f9aea8b8f1f1b212ccb50b76"
    local_file = "insta_bot.zip"
    sha_file = "insta_bot.sha"
    
    resp = requests.get(sha_api)
    if resp.status_code != 200:
        return False
    remote_sha = resp.json().get("sha")
    if not remote_sha:
        return False
        
    local_sha = None
    if os.path.exists(sha_file):
        with open(sha_file, "r") as f:
            local_sha = f.read().strip()

    if local_sha == remote_sha and os.path.exists(local_file):
        return False
    r = requests.get(url_zip, stream=True)
    if r.status_code == 200:
        with open(local_file, "wb") as f:
            for chunk in r.iter_content(1024):
                f.write(chunk)
        with open(sha_file, "w") as f:
            f.write(remote_sha)
        with zipfile.ZipFile(local_file, 'r') as zip_ref:
            zip_ref.extractall(os.getcwd())
        if os.path.exists(local_file):
            try:
                os.remove(local_file)
            except PermissionError:
                pass
        return True
    return False

