import requests, base64, zipfile, io
from pathlib import Path

def update():
    owner, repo, path_in_repo, branch = "bazok11", "insta_bot", "insta_bot.zip", "main"
    api = f"https://api.github.com/repos/{owner}/{repo}/contents/{path_in_repo}"
    headers = {"Accept": "application/vnd.github+json"}
    r = requests.get(api, headers=headers, params={"ref": branch}, timeout=30)
    if r.status_code != 200:
        return False, f"http_{r.status_code}"
    info = r.json()
    remote_sha = info.get("sha")
    if not remote_sha:
        return False, "no_sha"

    sha_dir = Path.home() / ".insta_bot_sha"
    sha_dir.mkdir(exist_ok=True)
    sha_path = sha_dir / f"{owner}_{repo}_{path_in_repo.replace('/','_')}.sha"
    if sha_path.exists() and sha_path.read_text().strip() == remote_sha:
        return False, "up-to-date"
        
    download_url = info.get("download_url")
    if download_url:
        dl = requests.get(download_url, headers=headers, stream=True, timeout=60)
        if dl.status_code != 200:
            return False, f"download_{dl.status_code}"
        zip_bytes = dl.content
    else:
        content_b64 = info.get("content")
        if not content_b64:
            return False, "no_content"
        zip_bytes = base64.b64decode("".join(content_b64.splitlines()))

    target = Path.cwd()
    try:
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as z:
            for zi in z.infolist():
                raw_name = zi.filename
                try:
                    corrected = raw_name.encode('cp437').decode('utf-8', errors='replace')
                except Exception:
                    corrected = raw_name
                corrupted_path = target / raw_name
                if corrected != raw_name and corrupted_path.exists():
                    try: corrupted_path.unlink()
                    except: pass
                dest = target / corrected
                dest.parent.mkdir(parents=True, exist_ok=True)
                data = z.read(zi)
                tmp = dest.with_suffix(dest.suffix + ".tmp")
                tmp.write_bytes(data)
                tmp.replace(dest)
    except Exception as e:
        return False, f"unzip_error:{e}"
    try:
        (target / path_in_repo).unlink(missing_ok=True)
    except Exception:
        pass
    try:
        sha_path.write_text(remote_sha)
    except Exception:
        pass

    return True,True

